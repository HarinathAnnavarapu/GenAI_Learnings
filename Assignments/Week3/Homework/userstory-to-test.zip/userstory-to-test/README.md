# User Story → Tests

This repository implements a small tool to convert user stories (and Jira issues) into test cases and to generate sample test data.

## Contents

- frontend/: React + Vite + TypeScript UI.
- backend/: Express + TypeScript API that proxies Jira and generates tests.

## High-level architecture

- The frontend calls backend endpoints under `/api/*`. The frontend uses `frontend/src/api.ts` which exposes helper functions such as `generateTests`, `fetchJiraDetails`, `fetchJiraProjects`, and `fetchJiraIssues`.
- The backend is an Express server (`backend/src/server.ts`) that mounts routers and exposes:
  - `POST /api/generate-tests` — generate tests from a story payload.
  - `GET /api/jira/issue/:id` — fetch and map Jira issue details (title, description, acceptanceCriteria).
  - `GET /api/jira/search` — search issues using projectKey or JQL.
  - `GET /api/jira/projects` — list Jira projects.
  - `GET /api/jira/raw` — raw proxy of the Jira issue payload.

## Key files and responsibilities

- frontend/src/App.tsx — main UI. Contains two exclusive screens: the Main screen (story input, category selection, generate) and Test Data Generator screen. These are toggled by `activeScreen` state.
- frontend/src/api.ts — client wrappers that call the backend API. Uses `import.meta.env.VITE_API_BASE_URL` or `http://localhost:8090/api` as a default.
- frontend/src/TestDataGenerator.tsx — UI and helpers to create sample CSV test data from a list of field definitions.
- backend/src/routes/jira.ts — Jira proxy routes, supports per-request credentials using custom request headers (x-jira-base-url, x-jira-username, x-jira-api-key/x-jira-token or x-jira-auth) and maps description to a plain text `acceptanceCriteria` field.
- backend/src/routes/generate.ts — generation logic (LLM or heuristics) that turns a story payload into test cases.
- backend/src/server.ts — Express entrypoint, loads `.env`, sets up CORS and mounts routers.

## Environment & configuration

- Frontend: optional env var `VITE_API_BASE_URL` to point to the backend API (e.g. http://localhost:8090/api).
- Backend: create a `.env` in `backend/` containing values such as:
  - JIRA_DNS (base url for Jira, e.g. https://yourdomain.atlassian.net)
  - JIRA_USERNAME
  - JIRA_API_KEY or JIRA_AUTH
  - JIRA_DEFAULT_PROJECT
  - JIRA_ACCEPTANCE_FIELD (optional custom field key to store acceptance criteria)
  - GROQ_API_BASE, GROQ_API_KEY, GROQ_MODEL (if using LLM integration)

Security note: don't commit secrets. The backend supports passing per-request Jira credentials via request headers for testing.

## How the Jira mapping works

- `backend/src/routes/jira.ts` attempts to read an acceptance criteria custom field (configurable via `JIRA_ACCEPTANCE_FIELD`). If not present, it falls back to parsing the issue description.
- The route converts Atlassian ADF (if present) to plain text and attempts to find a heading like "Acceptance Criteria" or "AC" and captures following bullets as the `acceptanceCriteria` value.
- The route returns a simplified JSON:
  {
    title: string,
    description: string,
    acceptanceCriteria: string,
    additionalInfo: string (JSON with labels, priority)
  }

## Running locally

1. Install dependencies

   npm install
   npm --prefix frontend install
   npm --prefix backend install

2. Start backend (recommended first)

   npm --prefix backend run dev

3. Start frontend

   npm --prefix frontend run dev

4. Open the Vite URL shown in the terminal (usually http://localhost:5173).

## Troubleshooting

- If the frontend can't reach the backend, set `VITE_API_BASE_URL` to `http://localhost:8090/api` (or whatever host:port your backend uses).
- If Jira calls fail, verify the headers or environment variables for username / API key. You can send credentials per-request using custom headers recognized by the backend (x-jira-base-url, x-jira-username, x-jira-api-key/x-jira-token or x-jira-auth).

## Notes for maintainers

- The frontend `App.tsx` was rewritten to avoid duplicate imports/exports and to ensure only one screen renders at a time (the `activeScreen` state). If you edit it, keep the file balanced and avoid adding duplicate top-level exports.
- The Jira proxy implements intelligent fallbacks for credentials and base URL. Respect the per-request override headers for testing.

---

If you'd like, I can now:
- Start the frontend dev server and report runtime output.
- Start the backend dev server and run quick smoke tests against the `/api/jira/issue/:id` and `/api/generate-tests` endpoints.
- Expand the README with example API payloads and curl commands.
