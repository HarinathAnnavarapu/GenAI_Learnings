const http = require('http');
const https = require('https');

function fetch(url) {
  return new Promise((resolve) => {
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    req.on('error', (err) => resolve({ error: err.message }));
  });
}

(async () => {
  const base = 'http://localhost:8090/api';
  console.log('Fetching health...');
  const h = await fetch(`${base}/health`);
  console.log('HEALTH:', JSON.stringify(h, null, 2));

  console.log('\nFetching Jira issue PROJ-123...');
  const j = await fetch(`${base}/jira/fetch?jiraId=PROJ-123`);
  console.log('JIRA FETCH:', JSON.stringify(j, null, 2));
})();
