import { useState } from 'react'
import { generateTests, fetchJiraDetails } from './api'
import TestDataGenerator from './TestDataGenerator'
import { GenerateRequest, GenerateResponse, TestCase } from './types'

function App() {
  const [activeScreen, setActiveScreen] = useState<string>('main')
  const [formData, setFormData] = useState<GenerateRequest>({
    storyTitle: '',
    acceptanceCriteria: '',
    description: '',
    additionalInfo: '',
    testCategories: []
  })
  const [results, setResults] = useState<GenerateResponse | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)
  const [actionMessage, setActionMessage] = useState<{ target?: string; text?: string } | null>(null)
  const [jiraCreds, setJiraCreds] = useState<{ baseUrl?: string; username?: string; apiKey?: string; projectKey?: string }>({})
  const [jiraProjects, setJiraProjects] = useState<Array<{ key: string; name: string }>>([])
  const [jiraIssues, setJiraIssues] = useState<Array<{ key: string; summary: string }>>([])
  const [projectsFetched, setProjectsFetched] = useState<boolean>(false)
  const [expandedTestCases, setExpandedTestCases] = useState<Set<string>>(new Set())

  const toggleTestCaseExpansion = (testCaseId: string) => {
    const newExpanded = new Set(expandedTestCases)
    if (newExpanded.has(testCaseId)) {
      newExpanded.delete(testCaseId)
    } else {
      newExpanded.add(testCaseId)
    }
    setExpandedTestCases(newExpanded)
  }

  const handleInputChange = (field: keyof GenerateRequest, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  // Extract Acceptance Criteria block (and subpoints) from a larger description string.
  const extractAcceptanceFromText = (text: string | undefined) => {
    const source = (text || '').trim()
    if (!source) return { description: '', acceptance: '' }

    // 1) Look for headings like "## Acceptance Criteria" or "Acceptance Criteria:" followed by content
    const headingMatch = source.match(/(^|\n)#{1,3}\s*Acceptance Criteria\s*\n([\s\S]*)/i)
    if (headingMatch) {
      const acceptance = headingMatch[2].trim()
      const remaining = source.replace(headingMatch[0], '').trim()
      return { description: remaining, acceptance }
    }

    const labelMatch = source.match(/(^|\n)(Acceptance Criteria|AC)[:\-]?\s*\n([\s\S]*)/i)
    if (labelMatch) {
      const acceptance = labelMatch[3].trim()
      const remaining = source.replace(labelMatch[0], '').trim()
      return { description: remaining, acceptance }
    }

    // 2) If no explicit heading, try to find a bullet list that looks like acceptance criteria near the end
    const bulletsAtEnd = source.match(/([\s\S]*?)\n(-|\*|\d+\.)\s+[\s\S]+$/)
    if (bulletsAtEnd) {
      // take the trailing list as acceptance criteria
      const before = bulletsAtEnd[1].trim()
      const list = source.replace(before, '').trim()
      // simple heuristic: only accept if list has multiple lines
      if ((list.match(/\n/g) || []).length >= 1) return { description: before, acceptance: list }
    }

    // fallback: no extraction
    return { description: source, acceptance: '' }
  }

  // Apply Jira data into the form ensuring acceptance criteria are pulled out from description when needed
  const applyFetchedJiraData = (data: any) => {
    const rawDescription = data.description || ''
    let finalAcceptance = data.acceptanceCriteria || ''
    let finalDescription = rawDescription || ''

    if (!finalAcceptance && finalDescription) {
      const parsed = extractAcceptanceFromText(finalDescription)
      finalDescription = parsed.description
      finalAcceptance = parsed.acceptance
    }

    let finalAdditional = data.additionalInfo || ''
    if (!finalAdditional) {
      const copy: any = { ...data }
      delete copy.title
      delete copy.description
      delete copy.acceptanceCriteria
      if (Object.keys(copy).length) finalAdditional = JSON.stringify(copy, null, 2)
    }

    setFormData(prev => ({
      ...prev,
      storyTitle: data.title || prev.storyTitle,
      description: finalDescription || prev.description,
      acceptanceCriteria: finalAcceptance || prev.acceptanceCriteria,
      additionalInfo: finalAdditional || prev.additionalInfo,
      jiraId: data.key || (prev as any).jiraId
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.storyTitle.trim() || !formData.acceptanceCriteria.trim()) {
      setError('Story Title and Acceptance Criteria are required')
      return
    }

    setIsLoading(true)
    setError(null)
    try {
      const response = await generateTests(formData)
      setResults(response)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate tests')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div>
  <style>{`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
          background-color: #f5f5f5;
          color: #333;
          line-height: 1.6;
        }
        
        .container {
          max-width: 95%;
          width: 100%;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
        }
        
        @media (min-width: 768px) {
          .container {
            max-width: 90%;
            padding: 30px;
          }
        }
        
        @media (min-width: 1024px) {
          .container {
            max-width: 85%;
            padding: 40px;
          }
        }
        
        @media (min-width: 1440px) {
          .container {
            max-width: 1800px;
            padding: 50px;
          }
        }
        
        .header {
          text-align: center;
          margin-bottom: 28px;
          background: linear-gradient(90deg, #5b86e5 0%, #36d1dc 100%);
          padding: 28px 18px;
          border-radius: 12px;
          color: white;
          box-shadow: 0 6px 30px rgba(54,209,220,0.08);
        }

        .title {
          font-size: 2.1rem;
          color: #ffffff;
          margin-bottom: 6px;
          letter-spacing: -0.5px;
        }

        .subtitle {
          color: rgba(255,255,255,0.92);
          font-size: 0.98rem;
          opacity: 0.95;
        }
        
        .form-container {
          background: linear-gradient(180deg,#ffffff 0%, #fbfdff 100%);
          border-radius: 12px;
          padding: 28px;
          box-shadow: 0 8px 30px rgba(31,56,87,0.06);
          margin-top: -28px;
          margin-bottom: 30px;
          border: 1px solid rgba(50, 93, 129, 0.03);
        }
        
        .form-group {
          margin-bottom: 20px;
        }
        
        .form-label {
          display: block;
          font-weight: 600;
          margin-bottom: 8px;
          color: #2c3e50;
        }
        
        .form-input, .form-textarea {
          width: 100%;
          padding: 12px 14px;
          border: 1px solid rgba(30,60,90,0.08);
          border-radius: 10px;
          font-size: 14px;
          transition: box-shadow 0.18s, border-color 0.18s;
          background: linear-gradient(180deg, #ffffff, #fbfdff);
        }
        
        .form-input:focus, .form-textarea:focus {
          outline: none;
          border-color: #3498db;
        }
        
        .form-textarea {
          resize: vertical;
          min-height: 100px;
        }
        
        .submit-btn {
          background: linear-gradient(90deg,#7b61ff,#00c2a8);
          color: white;
          border: none;
          padding: 10px 18px;
          border-radius: 999px;
          font-size: 15px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.12s, box-shadow 0.12s;
          box-shadow: 0 6px 18px rgba(59,91,255,0.08);
        }
        
        .submit-btn:hover:not(:disabled) {
          background: #2980b9;
           
        }
        
        .submit-btn:disabled {
          background: #bdc3c7;
          cursor: not-allowed;
        }
        
        .error-banner {
          background: #ff6b6b;
          color: white;
          padding: 12px 14px;
          border-radius: 8px;
          margin-bottom: 20px;
          box-shadow: 0 6px 20px rgba(255,107,107,0.08);
        }
        
        .loading {
          text-align: center;
          padding: 40px;
          color: #666;
          font-size: 18px;
        }
        
        .results-container {
          background: linear-gradient(180deg,#ffffff 0%, #fbfdff 100%);
          border-radius: 12px;
          padding: 22px;
          box-shadow: 0 8px 30px rgba(31,56,87,0.04);
          border: 1px solid rgba(30,60,90,0.03);
        }
        
        .results-header {
          margin-bottom: 20px;
          padding-bottom: 15px;
          border-bottom: 2px solid #e1e8ed;
        }
        
        .results-title {
          font-size: 1.8rem;
          color: #2c3e50;
          margin-bottom: 10px;
        }
        
        .results-meta {
          color: #666;
          font-size: 14px;
        }
        
        .table-container {
          overflow-x: auto;
        }
        
        .results-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        
        .results-table th,
        .results-table td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #e1e8ed;
        }
        
        .results-table th {
          background: #f8f9fa;
          font-weight: 600;
          color: #2c3e50;
        }
        
        .results-table tr:hover {
          background: #f8f9fa;
        }
        
        .category-positive { color: #27ae60; font-weight: 600; }
        .category-negative { color: #e74c3c; font-weight: 600; }
        .category-edge { color: #f39c12; font-weight: 600; }
        .category-authorization { color: #9b59b6; font-weight: 600; }
        .category-non-functional { color: #34495e; font-weight: 600; }
        
        .test-case-id {
          cursor: pointer;
          color: #3498db;
          font-weight: 600;
          padding: 8px 12px;
          border-radius: 4px;
          transition: background-color 0.2s;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }
        
        .test-case-id:hover {
          background: #f8f9fa;
        }
        
        .test-case-id.expanded {
          background: #e3f2fd;
          color: #1976d2;
        }
        
        .expand-icon {
          font-size: 10px;
          transition: transform 0.2s;
        }
        
        .expand-icon.expanded {
          transform: rotate(90deg);
        }
        
        .expanded-details {
          margin-top: 15px;
          background: #fafbfc;
          border: 1px solid #e1e8ed;
          border-radius: 8px;
          padding: 20px;
        }
        
        .step-item {
          background: white;
          border: 1px solid #e1e8ed;
          border-radius: 6px;
          padding: 15px;
          margin-bottom: 12px;
          box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        
        .step-header {
          display: grid;
          grid-template-columns: 80px 1fr 1fr 1fr;
          gap: 15px;
          align-items: start;
        }
        
        .step-id {
          font-weight: 600;
          color: #2c3e50;
          background: #f8f9fa;
          padding: 4px 8px;
          border-radius: 4px;
          text-align: center;
          font-size: 12px;
        }
        
        .step-description {
          color: #2c3e50;
          line-height: 1.5;
        }
        
        .step-test-data {
          color: #666;
          font-style: italic;
          font-size: 14px;
        }
        
        .step-expected {
          color: #27ae60;
          font-weight: 500;
          font-size: 14px;
        }
        
        .step-labels {
          display: grid;
          grid-template-columns: 80px 1fr 1fr 1fr;
          gap: 15px;
          margin-bottom: 10px;
          font-weight: 600;
          color: #666;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
          .category-pills {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 8px;
          }
          .pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: #fff;
            border: 1px solid #e1e8ed;
            border-radius: 999px;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, transform 0.08s;
            font-weight: 600;
            color: #2c3e50;
          }
          .pill:hover { transform: translateY(-1px); }
          .pill--selected {
            background: linear-gradient(90deg,#7b61ff,#00c2a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 8px 30px rgba(59,91,255,0.08);
            transform: translateY(-2px);
          }
          .pill-icon { font-size: 10px; opacity: 0.9 }
          .pill--selected .pill-icon { opacity: 1 }
      `}</style>
      
      <div className="container">
        {activeScreen === 'testdata' && <TestDataGenerator />}
        {activeScreen !== 'testdata' && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div className="header" style={{ flex: 1 }}>
          <h1 className="title">User Story to Tests</h1>
          <p className="subtitle">Generate comprehensive test cases from your user stories</p>
          </div>
          <div style={{ marginLeft: 12, display: 'flex', gap: 8 }}>
            <button className={`pill ${activeScreen === 'main' ? 'pill--selected' : ''}`} onClick={()=>setActiveScreen('main')}>Main</button>
            <button className={`pill ${activeScreen === 'testdata' ? 'pill--selected' : ''}`} onClick={()=>setActiveScreen('testdata')}>Test Data Generator</button>
          </div>
        </div>
       )}

  {error ? (
    <div className="error-banner" style={{ marginBottom: 16 }}>
      {error}
    </div>
  ) : null}
 

        <form onSubmit={handleSubmit} className="form-container">
          <div className="form-group" style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
            <input
              type="text"
              placeholder="Jira Base URL (e.g. https://yourcompany.atlassian.net)"
              className="form-input"
              value={jiraCreds.baseUrl || ''}
              onChange={(e) => setJiraCreds(prev => ({ ...prev, baseUrl: e.target.value }))}
              style={{ flex: '1 1 320px' }}
            />
            <input
              type="text"
              placeholder="Jira Username / Email"
              className="form-input"
              value={jiraCreds.username || ''}
              onChange={(e) => setJiraCreds(prev => ({ ...prev, username: e.target.value }))}
              style={{ flex: '0 0 260px' }}
            />
            <input
              type="password"
              placeholder="Jira API Token"
              className="form-input"
              value={jiraCreds.apiKey || ''}
              onChange={(e) => setJiraCreds(prev => ({ ...prev, apiKey: e.target.value }))}
              style={{ flex: '0 0 260px' }}
            />
            <select
              value={jiraCreds.projectKey || ''}
              onChange={(e) => setJiraCreds(prev => ({ ...prev, projectKey: e.target.value }))}
              className="form-input"
              style={{ flex: '0 0 200px', padding: '10px' }}
              disabled={!projectsFetched || jiraProjects.length === 0}
            >
              <option value="">Project (select after Fetch Projects)</option>
              {jiraProjects.map((p: any) => (
                <option key={p.key} value={p.key}>{p.key} — {p.name}</option>
              ))}
            </select>
            <button
              type="button"
              className="submit-btn"
              style={{ marginLeft: 8, background: '#8e44ad' }}
              onClick={async () => {
                // Fetch projects visible to the user
                if (!jiraCreds.baseUrl) { setError('Please enter Jira Base URL'); return }
                setIsLoading(true)
                setError(null)
                try {
                  const creds = { baseUrl: jiraCreds.baseUrl, username: jiraCreds.username, apiKey: jiraCreds.apiKey }
                  const res = await (await import('./api')).fetchJiraProjects(creds)
                  // populate select options
                  const projects = res.projects || []
                  setJiraIssues([]) // clear issues
                  setJiraProjects(projects)
                  setProjectsFetched(true)
                  setActionMessage({ target: 'projects', text: `Fetched ${projects.length} project(s)` })
                } catch (err) {
                  setError(err instanceof Error ? err.message : 'Failed to fetch projects')
                } finally { setIsLoading(false) }
              }}
            >
              Fetch Projects
            </button>
            <button
              type="button"
              className="submit-btn"
              onClick={async () => {
                // Connect and fetch issues for dropdown
                if (!jiraCreds.baseUrl) { setError('Please enter Jira Base URL'); return }
                const projectKey = jiraCreds.projectKey || ''
                if (!projectKey) {
                  setError("No project selected. Choose a project before connecting.")
                  return
                }
                setIsLoading(true)
                setError(null)
                try {
                  const creds = { baseUrl: jiraCreds.baseUrl, username: jiraCreds.username, apiKey: jiraCreds.apiKey }
                  const res = await (await import('./api')).fetchJiraIssues({ projectKey }, creds)
                  setJiraIssues(res.issues || [])
                  setActionMessage({ target: 'connect', text: `Fetched ${ (res.issues || []).length } story(ies)` })
                } catch (err) {
                  const msg = err instanceof Error ? err.message : 'Failed to fetch stories'
                  setError(msg)
                } finally { setIsLoading(false) }
              }}
              disabled={!jiraCreds.projectKey}
            >
              Connect & Fetch Stories
            </button>
            {actionMessage?.target === 'connect' && (
              <span style={{ marginLeft: 12, color: '#e60808ff', fontWeight: 600 }}>{actionMessage.text}</span>
            )}
          </div>
          <div style={{ marginTop: 8, marginBottom: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
            <select
              value={(formData as any).jiraId || ''}
              onChange={async (e) => {
                const selected = e.target.value
                setFormData(prev => ({ ...prev, jiraId: selected }))
                if (!selected) return
                setIsLoading(true)
                try {
                  const creds = { baseUrl: jiraCreds.baseUrl, username: jiraCreds.username, apiKey: jiraCreds.apiKey }
                  const data = await fetchJiraDetails(selected, creds)
                  applyFetchedJiraData(data)
                } catch (err) {
                  setError(err instanceof Error ? err.message : 'Failed to fetch Jira details')
                } finally { setIsLoading(false) }
              }}
              style={{ flex: '0 0 420px', padding: '10px', borderRadius: 6, border: '1px solid #e1e8ed' }}
            >
              <option value="">Select an issue...</option>
              {jiraIssues.map(i => <option key={i.key} value={i.key}>{i.key} — {i.summary}</option>)}
            </select>
            {/* Fetch Raw removed per requirements */}
          </div>
          <div className="form-group" style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <button
              type="button"
              className="submit-btn"
              onClick={async () => {
                const jiraId = (formData as any).jiraId
                if (!jiraId) { setError('Please enter a Jira ID'); return }
                setIsLoading(true)
                try {
                  const creds = { baseUrl: jiraCreds.baseUrl, username: jiraCreds.username, apiKey: jiraCreds.apiKey }
                  const data = await fetchJiraDetails(jiraId, creds)
                  applyFetchedJiraData(data)
                  setActionMessage({ target: 'fetchDetails', text: 'Jira details loaded' })
                } catch (err) {
                  setError(err instanceof Error ? err.message : 'Failed to fetch Jira details')
                } finally { setIsLoading(false) }
              }}
            >
              Fetch Jira Details
            </button>
            {/* Inline message for fetch details */}
            {actionMessage?.target === 'fetchDetails' && (
              <span style={{ marginLeft: 12, color: '#2c3e50', fontWeight: 600 }}>{actionMessage.text}</span>
            )}
            {/* Fetch Raw removed per requirements */}
            {/* Create/Update/Delete removed per requirements */}
          </div>
          <div className="form-group">
            <label htmlFor="storyTitle" className="form-label">
              Story Title *
            </label>
            <input
              type="text"
              id="storyTitle"
              className="form-input"
              value={formData.storyTitle}
              onChange={(e) => handleInputChange('storyTitle', e.target.value)}
              placeholder="Enter the user story title..."
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="description" className="form-label">
              Description
            </label>
            <textarea
              id="description"
              className="form-textarea"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Additional description (optional)..."
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="acceptanceCriteria" className="form-label">
              Acceptance Criteria *
            </label>
            <textarea
              id="acceptanceCriteria"
              className="form-textarea"
              value={formData.acceptanceCriteria}
              onChange={(e) => handleInputChange('acceptanceCriteria', e.target.value)}
              placeholder="Enter the acceptance criteria..."
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="additionalInfo" className="form-label">
              Additional Info
            </label>
            <textarea
              id="additionalInfo"
              className="form-textarea"
              value={formData.additionalInfo}
              onChange={(e) => handleInputChange('additionalInfo', e.target.value)}
              placeholder="Any additional information (optional)..."
            />
          </div>

          <div className="form-group">
            <label htmlFor="testCategories" className="form-label">
              Test Categories
            </label>
            <div id="testCategories" className="category-pills">
              {['Positive', 'Negative', 'Edge', 'Authorization', 'Non-Functional'].map((cat: string) => {
                const selected = formData.testCategories.includes(cat)
                return (
                  <button
                    key={cat}
                    type="button"
                    className={`pill ${selected ? 'pill--selected' : ''}`}
                    onClick={() => {
                      setFormData(prev => {
                        const exists = prev.testCategories.includes(cat)
                        return {
                          ...prev,
                          testCategories: exists
                            ? prev.testCategories.filter(c => c !== cat)
                            : [...prev.testCategories, cat]
                        }
                      })
                    }}
                    aria-pressed={selected}
                  >
                    <span className="pill-icon">●</span>
                    <span className="pill-label">{cat}</span>
                  </button>
                )
              })}
            </div>
          </div>
          
          <button
            type="submit"
            className="submit-btn"
            disabled={isLoading}
          >
            {isLoading ? 'Generating...' : 'Generate'}
          </button>
        </form>

        {error && 
          <div className="error-banner">
            {error}
          </div>
        }

        {isLoading && (
          <div className="loading">
            Generating test cases...
          </div>
        )}

        {results && (
          <div className="results-container">
            <div className="results-header">
              <h2 className="results-title">Generated Test Cases</h2>
              <div className="results-meta">
                {results.cases.length} test case(s) generated
                {results.model && ` • Model: ${results.model}`}
                {results.promptTokens > 0 && ` • Tokens: ${results.promptTokens + results.completionTokens}`}
              </div>
            </div>
            
            <div className="table-container">
              <table className="results-table">
                <thead>
                  <tr>
                    <th>Test Case ID</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Expected Result</th>
                  </tr>
                </thead>
                <tbody>
                  {results.cases.map((testCase: TestCase) => (
                    <>
                      <tr key={testCase.id}>
                        <td>
                          <div 
                            className={`test-case-id ${expandedTestCases.has(testCase.id) ? 'expanded' : ''}`}
                            onClick={() => toggleTestCaseExpansion(testCase.id)}
                          >
                            <span className={`expand-icon ${expandedTestCases.has(testCase.id) ? 'expanded' : ''}`}>
                              ▶
                            </span>
                            {testCase.id}
                          </div>
                        </td>
                        <td>{testCase.title}</td>
                        <td>
                          <span className={`category-${testCase.category.toLowerCase()}`}>
                            {testCase.category}
                          </span>
                        </td>
                        <td>{testCase.expectedResult}</td>
                      </tr>
                      {expandedTestCases.has(testCase.id) && (
                        <tr key={`${testCase.id}-details`}>
                          <td colSpan={4}>
                            <div className="expanded-details">
                              <h4 style={{marginBottom: '15px', color: '#2c3e50'}}>Test Steps for {testCase.id}</h4>
                              <div className="step-labels">
                                <div>Step ID</div>
                                <div>Step Description</div>
                                <div>Test Data</div>
                                <div>Expected Result</div>
                              </div>
                              {testCase.steps.map((step, index) => (
                                <div key={index} className="step-item">
                                  <div className="step-header">
                                    <div className="step-id">S{String(index + 1).padStart(2, '0')}</div>
                                    <div className="step-description">{step}</div>
                                    <div className="step-test-data">{testCase.testData || 'N/A'}</div>
                                    <div className="step-expected">
                                      {index === testCase.steps.length - 1 ? testCase.expectedResult : 'Step completed successfully'}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
         
      </div>
      
    </div>
  )
}

export default App