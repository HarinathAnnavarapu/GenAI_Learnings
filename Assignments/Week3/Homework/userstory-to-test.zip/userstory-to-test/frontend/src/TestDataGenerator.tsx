import { useState } from 'react'

type Requirement = 'Mandatory' | 'Optional' | 'Conditional'
type DataType = 'Name' | 'Email' | 'Integer' | 'Float' | 'Date' | 'Boolean' | 'Company' | 'Address' | 'Phone' | 'Text' | 'City' | 'Country' |'Currency' | 'UUID' | 'State' | 'Zip' | 'URL' | 'Section' | 'DateTime' | 'Timestamp' 

type FieldDef = {
  id: string
  name: string
  type: DataType
  requirement: Requirement
  conditional?: string
}

const rand = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min

const sampleNames = ['Alice', 'Bob', 'Charlie', 'Dana', 'Eve', 'Frank', 'Grace', 'Hugo']
const sampleCompanies = ['Acme Corp', 'Globex', 'Initech', 'Umbrella', 'Stark Industries']
const sampleCities = ['New York', 'San Francisco', 'London', 'Berlin', 'Sydney']
const sampleCountries = ['USA', 'UK', 'Germany', 'Australia', 'Canada']

function generateValue(type: DataType) {
  switch (type) {
    case 'Name': return sampleNames[rand(0, sampleNames.length - 1)]
    case 'Company': return sampleCompanies[rand(0, sampleCompanies.length - 1)]
    case 'City': return sampleCities[rand(0, sampleCities.length - 1)]
    case 'Country': return sampleCountries[rand(0, sampleCountries.length - 1)]
    case 'Email': {
      const n = sampleNames[rand(0, sampleNames.length - 1)].toLowerCase()
      return `${n}${rand(1,99)}@example.com`
    }
    case 'Integer': return String(rand(0, 1000))
    case 'Float': return (Math.random()*1000).toFixed(2)
    case 'Date': {
      const year = rand(2015, 2025)
      const month = String(rand(1,12)).padStart(2,'0')
      const day = String(rand(1,28)).padStart(2,'0')
      return `${year}-${month}-${day}`
    }
    case 'Boolean': return Math.random() > 0.5 ? 'true' : 'false'
    case 'Phone': return `+1-${rand(200,999)}-${rand(100,999)}-${rand(1000,9999)}`
    case 'Address': return `${rand(1,9999)} ${sampleNames[rand(0, sampleNames.length-1)]} St.`
    case 'Text': return 'Lorem ipsum dolor sit amet.'
    default: return ''
  }
}

export default function TestDataGenerator() {
  const [fields, setFields] = useState<FieldDef[]>([])
  const [name, setName] = useState('')
  const [type, setType] = useState<DataType>('Name')
  const [requirement, setRequirement] = useState<Requirement>('Mandatory')
  const [conditional, setConditional] = useState('')
  const [rows, setRows] = useState<Array<Record<string,string>>>([])
  const [count, setCount] = useState<number>(10)

  const addField = () => {
    if (!name.trim()) return
    const f: FieldDef = { id: String(Date.now()) + Math.random().toString(36).slice(2,6), name: name.trim(), type, requirement, conditional: conditional.trim() }
    setFields(prev => [...prev, f])
    setName('')
    setConditional('')
  }

  const removeField = (id: string) => setFields(prev => prev.filter(f => f.id !== id))

  const generate = () => {
    const out: Array<Record<string,string>> = []
    for (let i=0;i<count;i++) {
      const row: Record<string,string> = {}
      for (const f of fields) {
        // handle Optional: 20% nulls
        if (f.requirement === 'Optional' && Math.random() < 0.2) {
          row[f.name] = ''
          continue
        }
        // Conditional: for now treat as mandatory unless condition contains a simple "prob=xx" directive
        if (f.requirement === 'Conditional') {
          const m = (f.conditional||'').match(/prob=(\d{1,3})/) // e.g., prob=30
          if (m) {
            const p = Math.max(0, Math.min(100, Number(m[1])))
            if (Math.random()*100 >= p) { row[f.name] = ''; continue }
          }
        }
        row[f.name] = generateValue(f.type)
      }
      out.push(row)
    }
    setRows(out)
  }

  const downloadCSV = () => {
    if (rows.length === 0) return
    const keys = Object.keys(rows[0])
    const csv = [keys.join(',')].concat(rows.map(r => keys.map(k => `"${(r[k]||'').replace(/"/g,'""')}"`).join(','))).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'test-data.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div style={{ padding: 12 }}>
      <h2 style={{ marginBottom: 8 }}>Test Data Generator</h2>
      <p style={{ color: '#555' }}>Define fields and data types (inspired by Mockaroo). Add fields inline and click Generate to create sample rows.</p>

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 12, flexWrap: 'wrap' }}>
        <input className="form-input" placeholder="Field name" value={name} onChange={e=>setName(e.target.value)} style={{ minWidth: 160 }} />
        <select className="form-input" value={type} onChange={e=>setType(e.target.value as DataType)} style={{ minWidth: 160 }}>
          {['Name','Email','Integer','Float','Date','Boolean','Company','Address','Phone','Text','City','Country'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <select className="form-input" value={requirement} onChange={e=>setRequirement(e.target.value as Requirement)} style={{ minWidth: 160 }}>
          <option>Mandatory</option>
          <option>Optional</option>
          <option>Conditional</option>
        </select>
        <input className="form-input" placeholder="Conditional (e.g. prob=30)" value={conditional} onChange={e=>setConditional(e.target.value)} style={{ minWidth: 200 }} disabled={requirement!=='Conditional'} />
        <button className="submit-btn" type="button" onClick={addField} title="Add field">＋</button>
      </div>

      <div style={{ marginTop: 14 }}>
        {fields.length === 0 ? <div style={{ color: '#666' }}>No fields added yet.</div> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 8 }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', padding: 8 }}>Name</th>
                <th style={{ textAlign: 'left', padding: 8 }}>Type</th>
                <th style={{ textAlign: 'left', padding: 8 }}>Requirement</th>
                <th style={{ textAlign: 'left', padding: 8 }}>Conditional</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {fields.map(f => (
                <tr key={f.id}>
                  <td style={{ padding: 8 }}>{f.name}</td>
                  <td style={{ padding: 8 }}>{f.type}</td>
                  <td style={{ padding: 8 }}>{f.requirement}</td>
                  <td style={{ padding: 8 }}>{f.conditional || '-'}</td>
                  <td style={{ padding: 8 }}><button className="submit-btn" style={{ padding: '6px 10px' }} onClick={()=>removeField(f.id)}>Remove</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div style={{ marginTop: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
        <label style={{ color: '#444' }}>Rows:</label>
        <input className="form-input" type="number" value={count} onChange={e=>setCount(Math.max(1, Number(e.target.value)||1))} style={{ width: 100 }} />
        <button className="submit-btn" onClick={generate} disabled={fields.length===0}>Generate Test Data</button>
        <button className="submit-btn" onClick={downloadCSV} disabled={rows.length===0} style={{ background: '#4caf50' }}>Download CSV</button>
      </div>

      <div style={{ marginTop: 18 }}>
        {rows.length>0 && (
          <div className="results-container">
            <div style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong>Generated Sample ({rows.length} rows)</strong>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table className="results-table">
                <thead>
                  <tr>
                    {Object.keys(rows[0]).map(k => <th key={k}>{k}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r, idx) => (
                    <tr key={idx}>
                      {Object.keys(r).map(k => <td key={k}>{r[k]}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
