
export type JiraCreds = { baseUrl?: string; username?: string; apiKey?: string; auth?: string }

const buildCredHeaders = (creds?: JiraCreds) => {
  const headers: any = {}
  if (!creds) return headers
  if (creds.baseUrl) headers['x-jira-base-url'] = creds.baseUrl
  if (creds.username) headers['x-jira-username'] = creds.username
  if (creds.apiKey) headers['x-jira-api-key'] = creds.apiKey
  if (creds.auth) headers['x-jira-auth'] = creds.auth
  return headers
}

export async function fetchJiraDetails(jiraId: string, creds?: JiraCreds): Promise<any> {
  try {
      const url = `${API_BASE_URL}/jira/issue/${encodeURIComponent(jiraId)}`
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...buildCredHeaders(creds)
      },
    })

    const text = await response.text().catch(() => '')
    let body: any = null
    try { body = text ? JSON.parse(text) : null } catch (_) { body = text }

    if (!response.ok) {
      // Extract helpful jira error messages when present
      let messages: string[] = []
      if (body && typeof body === 'object') {
        if (Array.isArray(body.errorMessages)) messages = body.errorMessages
        else if (body.body && Array.isArray(body.body.errorMessages)) messages = body.body.errorMessages
        else if (body.message) messages = [body.message]
      }
      const msg = messages.length ? messages.join('; ') : (typeof body === 'string' ? body : JSON.stringify(body))
      throw new Error(`Jira fetch failed: ${response.status} ${response.statusText} - ${msg}`)
    }
    return body
  } catch (err) {
    console.error('fetchJiraDetails error', err)
    throw err instanceof Error ? err : new Error('Unknown error')
  }
}

export async function fetchJiraRaw(jiraId: string, creds?: JiraCreds): Promise<any> {
  try {
    const url = `${API_BASE_URL}/jira/raw?jiraId=${encodeURIComponent(jiraId)}`
    const response = await fetch(url, { headers: { ...buildCredHeaders(creds) } })
    const text = await response.text().catch(() => '')
    let body: any = text
    try { body = text ? JSON.parse(text) : null } catch (_) {}
    if (!response.ok) {
      throw new Error(`Raw Jira fetch failed: ${response.status} ${response.statusText} - ${JSON.stringify(body)}`)
    }
    return body
  } catch (err) {
    console.error('fetchJiraRaw error', err)
    throw err instanceof Error ? err : new Error('Unknown error')
  }
}
export async function fetchJiraIssues(params: { projectKey?: string; jql?: string; maxResults?: number }, creds?: JiraCreds): Promise<any> {
  // Require at least one of projectKey or jql to avoid Jira returning a 400
  if (!params.projectKey && !params.jql) {
    throw new Error("projectKey or jql is required. Click 'Fetch Projects' to select a project or provide a JQL query.")
  }

  const url = `${API_BASE_URL}/jira/search?` + new URLSearchParams({ ...(params.projectKey ? { projectKey: params.projectKey } : {}), ...(params.jql ? { jql: params.jql } : {}), ...(params.maxResults ? { maxResults: String(params.maxResults) } : {}) })
  const resp = await fetch(url, { method: 'GET', headers: { ...buildCredHeaders(creds) } })
  const text = await resp.text().catch(() => '')
  let body: any = null
  try { body = text ? JSON.parse(text) : null } catch (_) { body = text }
  if (!resp.ok) {
    // Friendly handling for invalid projectKey
    try {
      const msgs = Array.isArray(body?.body?.errorMessages) ? body.body.errorMessages : Array.isArray(body?.errorMessages) ? body.errorMessages : []
      const invalidProjectMsg = msgs.find((m: string) => /does not exist for the field 'project'/.test(m))
      if (invalidProjectMsg) {
        const pk = params.projectKey || ''
        throw new Error(`Project key '${pk}' not found in Jira. Click 'Fetch Projects' to load available projects or enter a valid project key.`)
      }
    } catch (_) {}
    throw new Error(`Search Jira failed: ${resp.status} - ${JSON.stringify(body)}`)
  }
  return body
}

export async function fetchJiraProjects(creds?: JiraCreds): Promise<any> {
  const url = `${API_BASE_URL}/jira/projects`
  const resp = await fetch(url, { method: 'GET', headers: { ...buildCredHeaders(creds) } })
  const text = await resp.text().catch(() => '')
  let body: any = null
  try { body = text ? JSON.parse(text) : null } catch (_) { body = text }
  if (!resp.ok) throw new Error(`List Jira projects failed: ${resp.status} - ${JSON.stringify(body)}`)
  return body
}

export async function createJiraIssue(payload: any, creds?: JiraCreds): Promise<any> {
  const url = `${API_BASE_URL}/jira/create`
  const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...buildCredHeaders(creds) }, body: JSON.stringify(payload) })
  const text = await resp.text().catch(() => '')
  let body: any = null
  try { body = text ? JSON.parse(text) : null } catch (_) { body = text }
  if (!resp.ok) throw new Error(`Create Jira failed: ${resp.status} - ${JSON.stringify(body)}`)
  return body
}
export async function updateJiraIssue(jiraId: string, payload: any, creds?: JiraCreds): Promise<any> {
  const resp = await fetch(`${API_BASE_URL}/jira/issue/${encodeURIComponent(jiraId)}`, { method: 'PUT', headers: { 'Content-Type': 'application/json', ...buildCredHeaders(creds) }, body: JSON.stringify(payload) })
  if (!resp.ok) {
    const text = await resp.text().catch(() => '')
    let body: any = null
    try { body = text ? JSON.parse(text) : null } catch (_) { body = text }
    throw new Error(`Update Jira failed: ${resp.status} - ${JSON.stringify(body)}`)
  }
  return { ok: true }
}
export async function deleteJiraIssue(jiraId: string, creds?: JiraCreds): Promise<any> {
  const resp = await fetch(`${API_BASE_URL}/jira/issue/${encodeURIComponent(jiraId)}`, { method: 'DELETE', headers: { ...buildCredHeaders(creds) } })
  if (!resp.ok) {
    const text = await resp.text().catch(() => '')
    let body: any = null
    try { body = text ? JSON.parse(text) : null } catch (_) { body = text }
    throw new Error(`Delete Jira failed: ${resp.status} - ${JSON.stringify(body)}`)
  }
  return { ok: true }
}


import { GenerateRequest, GenerateResponse } from './types'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8090/api'
export async function generateTests(request: GenerateRequest): Promise<GenerateResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/generate-tests`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data: GenerateResponse = await response.json()
    return data
  } catch (error) {
    console.error('Error generating tests:', error)
    throw error instanceof Error ? error : new Error('Unknown error occurred')
  }
}

