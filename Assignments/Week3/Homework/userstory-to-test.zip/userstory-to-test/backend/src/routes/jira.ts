import express, { Router } from 'express'
import fetch from 'node-fetch'

const router = express.Router()
const JIRA_DNS = process.env.JIRA_DNS || 'https://haridece23.atlassian.net'
      const JIRA_BASEPATH = process.env.JIRA_BASEPATH || ''
      const JIRA_API_ENDPOINT = process.env.JIRA_API_ENDPOINT || '/rest/api/2/issue'
      const JIRA_USERNAME = process.env.JIRA_USERNAME || 'haridece23@gmail.com'
      const JIRA_AUTH = process.env.JIRA_AUTH
      
// helper to build headers (accept per-request overrides via request headers)
const trim = (v?: string) => v ? v.replace(/^\s*["']|["']\s*$/g, '').trim() : ''
const buildJiraHeaders = (reqHeaders?: any) => {
   const headers: any = { 'Accept': 'application/json', 'Content-Type': 'application/json' }
   const rawAuthHeader = trim(reqHeaders?.['x-jira-auth'] || reqHeaders?.['x-jira_token'] || reqHeaders?.['x-jira-token'])
   const rawBaseUrl = trim(reqHeaders?.['x-jira-base-url'] || reqHeaders?.['x-jira-baseurl'])
   const rawUsername = trim(reqHeaders?.['x-jira-username'] || reqHeaders?.['x-jira-user'])
   const rawToken = trim(reqHeaders?.['x-jira-api-key'] || reqHeaders?.['x-jira-token'])

   // Environment fallbacks
   const envAuth = trim(process.env.JIRA_AUTH)
   const envUser = trim(process.env.JIRA_USERNAME) || trim(process.env.JIRA_USER)
   const envToken = trim(process.env.JIRA_TOKEN)

   let authHeader: string | undefined
   if (rawAuthHeader) {
      if (rawAuthHeader.startsWith('Basic ') || rawAuthHeader.startsWith('Bearer ')) {
         authHeader = rawAuthHeader
      } else if (rawUsername) {
         authHeader = `Basic ${Buffer.from(`${rawUsername}:${rawAuthHeader}`).toString('base64')}`
      }
   } else if (rawToken && rawUsername) {
      authHeader = `Basic ${Buffer.from(`${rawUsername}:${rawToken}`).toString('base64')}`
   } else if (envAuth) {
      if (envAuth.startsWith('Basic ') || envAuth.startsWith('Bearer ')) authHeader = envAuth
      else if (envUser) authHeader = `Basic ${Buffer.from(`${envUser}:${envAuth}`).toString('base64')}`
   } else if (envUser && envToken) {
      authHeader = `Basic ${Buffer.from(`${envUser}:${envToken}`).toString('base64')}`
   }
   if (authHeader) headers['Authorization'] = authHeader
   return headers
}

// helper to resolve base URL per-request (req headers override env)
const resolveBaseUrl = (reqHeaders?: any) => {
   const rawBase = trim(reqHeaders?.['x-jira-base-url'] || reqHeaders?.['x-jira-baseurl']) || trim(process.env.JIRA_DNS)
   if (!rawBase) return ''
   return rawBase.replace(/\/$/, '')
}

router.get('/issue/:id', async (req, res) => {
   try {
      const { id: jiraId } = req.params
      if (!jiraId) return res.status(400).json({ error: 'jiraId is required' })

   const base = resolveBaseUrl(req.headers)
   if (!base) return res.status(500).json({ error: 'JIRA base URL not configured' })
   const endpoint = JIRA_API_ENDPOINT.startsWith('/') ? JIRA_API_ENDPOINT : `/${JIRA_API_ENDPOINT}`
   const url = `${base}${endpoint}/${encodeURIComponent(jiraId)}`
   console.log(`Fetching Jira issue from URL: ${url}`)

   const headers = buildJiraHeaders(req.headers)
   const resp = await fetch(url, { headers })
      const text = await resp.text().catch(() => '')
      let json: any = null
      try { json = text ? JSON.parse(text) : null } catch (e) { json = null }

      if (!resp.ok) {
         console.error('Jira responded with status', resp.status, text)
         const body = json || text
         return res.status(resp.status).json({ error: 'Failed to fetch from Jira', status: resp.status, body })
      }

      // Helper: convert Atlassian ADF description to plain text if needed
      const adfToPlainText = (node: any): string => {
         if (!node) return ''
         if (typeof node === 'string') return node
         // If node is an array, join
         if (Array.isArray(node)) return node.map(adfToPlainText).join('')

         // Text node
         if (node.type === 'text' && typeof node.text === 'string') return node.text

         // Headings -> include as a line with possible underline
         if (node.type === 'heading' && Array.isArray(node.content)) {
            const inner = node.content.map((c: any) => adfToPlainText(c)).join('')
            return `\n${inner}\n`
         }

         // Paragraph -> join children and add newline
         if (node.type === 'paragraph' && Array.isArray(node.content)) {
            const inner = node.content.map((c: any) => adfToPlainText(c)).join('')
            return `${inner}\n`
         }

         // Hard break
         if (node.type === 'hardBreak') return '\n'

         // Bullet list
         if (node.type === 'bulletList' && Array.isArray(node.content)) {
            return node.content.map((li: any) => {
               // li is a listItem
               const liText = adfToPlainText(li)
               // indent handling if nested
               return liText.split('\n').map((line: string, idx: number) => (line ? `${idx === 0 ? '- ' : '  '}${line}` : '')).join('\n')
            }).join('\n') + '\n'
         }

         // Ordered list
         if (node.type === 'orderedList' && Array.isArray(node.content)) {
            return node.content.map((li: any, i: number) => {
               const liText = adfToPlainText(li)
               return liText.split('\n').map((line: string, idx: number) => (line ? `${idx === 0 ? `${i + 1}. ` : '   '}${line}` : '')).join('\n')
            }).join('\n') + '\n'
         }

         // List item: usually contains paragraph(s)
         if (node.type === 'listItem' && Array.isArray(node.content)) {
            // concatenate children, preserving newlines
            return node.content.map((c: any) => adfToPlainText(c)).join('\n').replace(/\n{2,}/g, '\n')
         }

         // Generic container with content
         if (node.content && Array.isArray(node.content)) {
            return node.content.map((c: any) => adfToPlainText(c)).join('')
         }

         return ''
      }

      const descriptionRaw = json?.fields?.description || ''
      let descriptionText = ''
      try {
         if (typeof descriptionRaw === 'string') descriptionText = descriptionRaw
         else descriptionText = adfToPlainText(descriptionRaw)
      } catch (e) {
         descriptionText = String(descriptionRaw || '')
      }

      // Helper: extract acceptance criteria section from description text
      const extractAcceptanceFromDescription = (text: string) => {
         if (!text || typeof text !== 'string') return { acceptance: '', cleaned: text }
         // Look for common headings like 'Acceptance Criteria', 'Acceptance criteria', or 'AC:'
         const re = /(?:^|\n)\s*(?:Acceptance Criteria|Acceptance criteria|Acceptance|AC)\s*[:\-–]?\s*\n([\s\S]*?)(?=\n[A-Z][^\n]{0,120}?:|\n{2,}|$)/i
         const m = text.match(re)
         if (m && m[1]) {
            const acceptance = m[1].trim()
            // remove the matched section from the original text
            const cleaned = text.replace(m[0], '\n').replace(/\n{3,}/g, '\n\n').trim()
            return { acceptance, cleaned }
         }
         // also try inline 'Acceptance Criteria:' on same line
         const inlineRe = /Acceptance Criteria\s*[:\-–]\s*(.+)(?:\n|$)/i
         const mi = text.match(inlineRe)
         if (mi && mi[1]) {
            const acceptance = mi[1].trim()
            const cleaned = text.replace(mi[0], '').trim()
            return { acceptance, cleaned }
         }
         return { acceptance: '', cleaned: text }
      }

      // Primary: read acceptance from configured custom field if present
      const acceptanceField = process.env.JIRA_ACCEPTANCE_FIELD || 'customfield_10000'
      let acceptanceFromField = ''
      try { acceptanceFromField = json?.fields?.[acceptanceField] || '' } catch (_) { acceptanceFromField = '' }

      let acceptanceCriteria = ''
      let cleanedDescription = descriptionText
      if (acceptanceFromField && String(acceptanceFromField).trim()) {
         acceptanceCriteria = String(acceptanceFromField).trim()
      } else {
         const extracted = extractAcceptanceFromDescription(descriptionText)
         acceptanceCriteria = extracted.acceptance || ''
         cleanedDescription = extracted.cleaned || descriptionText
      }

      const mapped = {
         title: json?.fields?.summary || '',
         description: cleanedDescription || '',
         acceptanceCriteria: acceptanceCriteria || '',
         additionalInfo: JSON.stringify({ labels: json?.fields?.labels || [], priority: json?.fields?.priority }, null, 2)
      }

      return res.json(mapped)
   } catch (err) {
      console.error('jira fetch error', err)
      return res.status(500).json({ error: 'Failed to fetch Jira details', message: err instanceof Error ? err.message : String(err) })
   }
})

// Search issues for a project or using JQL. Returns array of { key, summary }
router.get('/search', async (req, res) => {
   try {
      const projectKey = (req.query.projectKey as string) || ''
      const jql = (req.query.jql as string) || ''
      const maxResults = Number(req.query.maxResults || 50)

      const base = resolveBaseUrl(req.headers)
      if (!base) return res.status(500).json({ error: 'JIRA base URL not configured' })
      const searchEndpoint = '/rest/api/2/search'
      const url = `${base}${searchEndpoint}`

      let queryJql = jql
      if (!queryJql && projectKey) queryJql = `project = ${projectKey} AND issuetype = Story ORDER BY updated DESC`
      if (!queryJql) return res.status(400).json({ error: 'projectKey or jql is required' })

      const headers = buildJiraHeaders(req.headers)
      const body = { jql: queryJql, maxResults }
      const resp = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) })
      const text = await resp.text().catch(() => '')
      let json: any = null
      try { json = text ? JSON.parse(text) : null } catch (e) { json = null }
      if (!resp.ok) return res.status(resp.status).json({ error: 'Failed to search Jira', status: resp.status, body: json || text })

      const issues = (json?.issues || []).map((iss: any) => ({ key: iss.key, summary: iss.fields?.summary || '' }))
      return res.json({ total: json?.total || issues.length, issues })
   } catch (err) {
      console.error('jira search error', err)
      return res.status(500).json({ error: 'Failed to search Jira issues', message: err instanceof Error ? err.message : String(err) })
   }
})

// List projects visible to the authenticated user
router.get('/projects', async (req, res) => {
   try {
      const base = resolveBaseUrl(req.headers)
      if (!base) return res.status(500).json({ error: 'JIRA base URL not configured' })
      const url = `${base}/rest/api/2/project`
      const headers = buildJiraHeaders(req.headers)
      const resp = await fetch(url, { method: 'GET', headers })
      const text = await resp.text().catch(() => '')
      let json: any = null
      try { json = text ? JSON.parse(text) : null } catch (e) { json = null }
      if (!resp.ok) return res.status(resp.status).json({ error: 'Failed to list Jira projects', status: resp.status, body: json || text })

      // Map to simple list
      const projects = (Array.isArray(json) ? json : []).map((p: any) => ({ key: p.key, name: p.name, id: p.id }))
      return res.json({ total: projects.length, projects })
   } catch (err) {
      console.error('jira projects error', err)
      return res.status(500).json({ error: 'Failed to list Jira projects', message: err instanceof Error ? err.message : String(err) })
   }
})

// Raw proxy endpoint to return the entire Jira response (status and body)
router.get('/raw', async (req, res) => {
   try {
      const jiraId = (req.query.jiraId as string) || ''
      if (!jiraId) return res.status(400).json({ error: 'jiraId is required' })

   const base = resolveBaseUrl(req.headers)
   if (!base) return res.status(500).json({ error: 'JIRA base URL not configured' })
   const endpoint = JIRA_API_ENDPOINT.startsWith('/') ? JIRA_API_ENDPOINT : `/${JIRA_API_ENDPOINT}`
   const url = `${base}${endpoint}/${encodeURIComponent(jiraId)}`
   console.log(`[raw] Fetching Jira issue from URL: ${url}`)
   const headers = buildJiraHeaders(req.headers)
   const resp = await fetch(url, { headers })
      const text = await resp.text().catch(() => '')
      let json: any = null
      try { json = text ? JSON.parse(text) : null } catch (e) { json = null }

      // forward status and body exactly so caller can inspect fields
      return res.status(resp.status).json({ status: resp.status, body: json || text })
   } catch (err) {
      console.error('jira raw error', err)
      return res.status(500).json({ error: 'Failed to fetch raw Jira details', message: err instanceof Error ? err.message : String(err) })
   }
})

      // Create a Jira issue
      router.post('/create', async (req, res) => {
         try {
            const { storyTitle, description, acceptanceCriteria, additionalInfo, projectKey } = req.body
            const JIRA_PROJECT = projectKey || process.env.JIRA_DEFAULT_PROJECT
            if (!JIRA_PROJECT) return res.status(400).json({ error: 'projectKey or JIRA_DEFAULT_PROJECT required' })

            // Map fields; allow overriding acceptance field via env
            const acceptanceField = process.env.JIRA_ACCEPTANCE_FIELD || 'customfield_10000'

            const payload: any = {
               fields: {
                  project: { key: JIRA_PROJECT },
                  summary: storyTitle || 'No title',
                  description: description || '',
                  issuetype: { name: process.env.JIRA_ISSUE_TYPE || 'Story' }
               }
            }
            if (acceptanceCriteria) payload.fields[acceptanceField] = acceptanceCriteria
            if (additionalInfo) payload.fields['labels'] = (additionalInfo.labels) ? additionalInfo.labels : undefined

            const base = resolveBaseUrl(req.headers)
            if (!base) return res.status(500).json({ error: 'JIRA base URL not configured' })
            const url = `${base}/rest/api/2/issue`
            const headers = buildJiraHeaders(req.headers)
            const resp = await fetch(url, { method: 'POST', headers, body: JSON.stringify(payload) })
            const text = await resp.text().catch(() => '')
            let json: any = null
            try { json = text ? JSON.parse(text) : null } catch (e) { json = null }
            if (!resp.ok) return res.status(resp.status).json({ error: 'Failed to create Jira issue', status: resp.status, body: json || text })
            return res.status(201).json(json)
         } catch (err) {
            console.error('jira create error', err)
            return res.status(500).json({ error: 'Failed to create Jira issue', message: err instanceof Error ? err.message : String(err) })
         }
      })

      // Update a Jira issue
   router.put('/issue/:id', async (req, res) => {
         try {
            const { id: jiraId } = req.params
            const { storyTitle, description, acceptanceCriteria, additionalInfo } = req.body
            if (!jiraId) return res.status(400).json({ error: 'jiraId is required' })

            const acceptanceField = process.env.JIRA_ACCEPTANCE_FIELD || 'customfield_10000'
            const payload: any = { fields: {} }
            if (storyTitle) payload.fields.summary = storyTitle
            if (description) payload.fields.description = description
            if (acceptanceCriteria) payload.fields[acceptanceField] = acceptanceCriteria
            if (additionalInfo) payload.fields['labels'] = (additionalInfo.labels) ? additionalInfo.labels : undefined

            const base = resolveBaseUrl(req.headers)
            if (!base) return res.status(500).json({ error: 'JIRA base URL not configured' })
            const url = `${base}/rest/api/2/issue/${encodeURIComponent(jiraId)}`
            const headers = buildJiraHeaders(req.headers)
            const resp = await fetch(url, { method: 'PUT', headers, body: JSON.stringify(payload) })
            if (!resp.ok) {
               const text = await resp.text().catch(() => '')
               let json: any = null
               try { json = text ? JSON.parse(text) : null } catch (e) { json = null }
               return res.status(resp.status).json({ error: 'Failed to update Jira issue', status: resp.status, body: json || text })
            }
            return res.json({ ok: true })
         } catch (err) {
            console.error('jira update error', err)
            return res.status(500).json({ error: 'Failed to update Jira issue', message: err instanceof Error ? err.message : String(err) })
         }
      })

      // Delete a Jira issue
   router.delete('/issue/:id', async (req, res) => {
         try {
            const { id: jiraId } = req.params
            if (!jiraId) return res.status(400).json({ error: 'jiraId is required' })
            const base = resolveBaseUrl(req.headers)
            if (!base) return res.status(500).json({ error: 'JIRA base URL not configured' })
            const url = `${base}/rest/api/2/issue/${encodeURIComponent(jiraId)}`
            const headers = buildJiraHeaders(req.headers)
            const resp = await fetch(url, { method: 'DELETE', headers })
            if (!resp.ok) {
               const text = await resp.text().catch(() => '')
               let json: any = null
               try { json = text ? JSON.parse(text) : null } catch (e) { json = null }
               return res.status(resp.status).json({ error: 'Failed to delete Jira issue', status: resp.status, body: json || text })
            }
            return res.json({ ok: true })
         } catch (err) {
            console.error('jira delete error', err)
            return res.status(500).json({ error: 'Failed to delete Jira issue', message: err instanceof Error ? err.message : String(err) })
         }
      })
export default router

